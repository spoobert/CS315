#ifndef CELL_HPP
#define CELL_HPP

struct cell {
  int x;
  int y;
};

#endif
