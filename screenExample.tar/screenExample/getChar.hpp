extern char get_char( void );

